INSERT IGNORE INTO owners VALUES (NULL, '110 W. Liberty St.', 'George', 'Franklin', '6085551023');
INSERT IGNORE INTO owners VALUES (NULL, '638 Cardinal Ave.', 'Betty', 'Davis', '6085551749');
INSERT IGNORE INTO owners VALUES (NULL, '2693 Commerce St.', 'Eduardo', 'Rodriquez', '6085558763');
